#pragma once

#define HTTP_SERVER "74.201.28.102"
#define HTTP_PORT 80

#define TFTP_SERVER "74.201.28.102"
